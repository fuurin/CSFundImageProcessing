import sys

i=2
while i<len(sys.argv):
    print "elif \'"+sys.argv[1]+"\' in Pokemon1.variety and \'"+sys.argv[i]+"\' in Pokemon2.variety :return True"
    i=i+1
