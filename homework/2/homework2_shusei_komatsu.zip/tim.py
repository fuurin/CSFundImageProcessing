def timSort(alist):
    alist.sort()
    return alist